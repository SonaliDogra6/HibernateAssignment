package com.miniau.firsthibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="salaryMap")
public class Salary {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int  id;
	
	@Column(name="inRupee")
	private int inRupee;
	
	@Column(name="inDollar")
	private int inDollar;
	
//	@ManyToOne()
//	@JoinColumn(name="salary_id")
//	Person person;


	public int getInRupee() {
		return inRupee;
	}

	public void setInRupee(int inRupee) {
		this.inRupee = inRupee;
	}

	public int getInDollar() {
		return inDollar;
	}

	public void setInDollar(int inDollar) {
		this.inDollar = inDollar;
	}

	@Override
	public String toString() {
		return "Salary [id=" + id + ", inRupee=" + inRupee + ", inDollar=" + inDollar + "]";
	}
}
