package com.miniau.firsthibernate.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.miniau.firsthibernate.dao.PersonDao;
import com.miniau.firsthibernate.model.Person;

public class PersonDaoImpl implements PersonDao{

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(Person p) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession(); //bind query/request from one thread 
		Transaction tx = session.beginTransaction(); //transaction object 
		session.persist(p); // store value of object to session
		tx.commit();	// save to database
		session.close();
		return true;
	}

	public boolean delete(int id) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction(); 
		Person p= (Person) session.load(Person.class, id);
		if(p!=null)
			session.delete(p);
		tx.commit();
		session.close();
		return true;
	}

	public List<Person> getAll() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		List<Person> persons = session.createQuery("from Person").list();//"Person" is class name
		session.close();
		return persons;
	}

	public Person getById(int id) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction(); 
		Person p= (Person) session.load(Person.class, id);
		//if(p!=null)
		return p;	
	}
	public boolean update(Person p) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction(); 
		p.setId(19);
		p.setName("Jasgeet");
		p.setAge(30);
		session.update(p);
		tx.commit();
		session.close();
		return true;
	}

}
