 package com.miniau.firsthibernate;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.miniau.firsthibernate.dao.PersonDao;
import com.miniau.firsthibernate.model.Mapping;
import com.miniau.firsthibernate.model.Person;
import com.miniau.firsthibernate.model.Salary;


public class HibernatApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		PersonDao personDao = context.getBean(PersonDao.class);
		
		Person p= new Person();
		p.setName("Sumit");
		p.setAge(50);
		p.setSalary(40000);
		
		Mapping m= new Mapping();
		m.setFirstName("sonali");
		m.setMiddleName("singh");
		m.setLastName("rajput");
		
		p.setNameMap(m);
		
		Set<Salary> sal= new HashSet<Salary>();
		Salary s1= new Salary();
		Salary s2 = new Salary();
		s1.setInRupee(70000);
		s1.setInDollar(1000);
		sal.add(s1);
		s2.setInRupee(140000);
		s2.setInDollar(2000);
		sal.add(s2);
		p.setSalaryMap(sal);
		
		personDao.save(p);
		
		//personDao.delete(13);
//		Person per= personDao.getById(3);
//		System.out.println(per);
		
		List<Person> list = personDao.getAll();
		for(Person person :list) {
			System.out.println(person+" ");
		}
	}
}
