package com.miniau.firsthibernate.dao;

import java.util.List;

import com.miniau.firsthibernate.model.Person;

public interface PersonDao {
	public boolean save(Person p);
	public boolean delete(int id);
	public List<Person> getAll();
	public boolean update(Person p);
	public Person getById(int id);
	
}
