package com.miniau.firsthibernate.model;

import java.sql.Time;
import java.util.Set;

import javax.persistence.*;


@Entity
@Table(name="person")
public class Person {
	@Id //ID is the primary key of table
	@Column(name="id") // name of table column is id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto generation of identity equivalent to auto increment
	private int  id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="age")
	private int age;
	
	@Column(name="salary")
	private int salary;
	
	@Column(name="createdAt")
	//@Temporal(TemporalType.TIMESTAMP)
	private Time createdAt;
	
	@Column(name="updatedAt")
	//@Temporal(TemporalType.TIMESTAMP)
	private Time updatedAt;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="name_id")
	private Mapping nameMap;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="person_id")
	Set<Salary> salaryMap;
	
	public void setSalaryMap(Set<Salary> salaryMap) {
		this.salaryMap = salaryMap;
	}
	public Mapping getNameMap() {
		return nameMap;
	}
	public void setNameMap(Mapping nameMap) {
		this.nameMap = nameMap;
	}

	//@OneToMany(mappedBy="person")
//	@JoinColumn(name="salary_id")
//	private Salary<Set> salaryMap;
//	@OneToMany(mappedBy="cart")
//    private Set<Items> items;

//	public Salary getSalaryMap() {
//		return salaryMap;
//	}
//	
//	public void setSalaryMap(Salary salaryMap) {
//		this.salaryMap = salaryMap;
//	}

	public Person() {
		super();
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public Time getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Time createdAt) {
		this.createdAt = createdAt;
	}
	public Time getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Time updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + ", createdAt="
				+ createdAt + ", updatedAt=" + updatedAt + ", nameMap=" + nameMap + ", salaryMap=" + salaryMap + "]";
	}

	
	
	
}
