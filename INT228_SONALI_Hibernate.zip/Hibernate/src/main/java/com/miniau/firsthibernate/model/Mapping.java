package com.miniau.firsthibernate.model;

import java.sql.Time;

import javax.persistence.*;

@Entity
@Table(name="nameMap")
public class Mapping {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int  id;
	
	@Column(name="firstName")
	private String firstName;
	
	@Column(name="middleName")
	private String middleName;
	
	@Column(name="lastName")
	private String lastName ;
	
	@Column(name="createdAt")
	//@Temporal(TemporalType.TIMESTAMP)
	private Time createdAt;
	
	@Column(name="updatedAt")
	//@Temporal(TemporalType.TIMESTAMP)
	private Time updatedAt;
	
//	@OneToOne(mappedBy="person")
//	Person person;
	
	public Mapping() {
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Time getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Time createdAt) {
		this.createdAt = createdAt;
	}
	public Time getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Time updatedAt) {
		this.updatedAt = updatedAt;
	}


	@Override
	public String toString() {
		return "Mapping [id=" + id + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
	}

	
}
